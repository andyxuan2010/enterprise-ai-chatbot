# Enterprise RAG Chatbot on Azure OpenAI

This sample contains a minimal but enterprise-oriented Azure RAG assistant implementation:

- Terraform for Azure OpenAI, Azure AI Search, App Service, Storage, Key Vault, private endpoints, and RBAC.
- Python ingestion script for documents.
- FastAPI backend for RAG chat.
- GitHub Actions workflow for Terraform deployment.

This is a starter skeleton. Validate Azure OpenAI model availability, private networking, DNS, and organization-specific security controls before production use.
