output "resource_group_name" { value = azurerm_resource_group.rg.name }
output "app_name" { value = azurerm_linux_web_app.app.name }
output "app_default_hostname" { value = azurerm_linux_web_app.app.default_hostname }
output "openai_endpoint" { value = azurerm_cognitive_account.openai.endpoint }
output "search_endpoint" { value = "https://${azurerm_search_service.search.name}.search.windows.net" }
output "storage_account_name" { value = azurerm_storage_account.docs.name }
output "storage_container_name" { value = azurerm_storage_container.docs.name }
