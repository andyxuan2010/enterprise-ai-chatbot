variable "prefix" {
  description = "Short workload prefix. Example: ragdemo. Must be globally unique enough for PaaS names."
  type        = string
  default     = "ragdemo"
}

variable "location" {
  description = "Azure region. Confirm model availability before deployment."
  type        = string
  default     = "canadacentral"
}

variable "environment" {
  description = "Environment name."
  type        = string
  default     = "dev"
}

variable "address_space" {
  type    = list(string)
  default = ["10.80.0.0/20"]
}

variable "app_subnet_prefix" {
  type    = list(string)
  default = ["10.80.1.0/24"]
}

variable "private_endpoint_subnet_prefix" {
  type    = list(string)
  default = ["10.80.2.0/24"]
}

variable "openai_chat_model_name" {
  description = "Azure OpenAI model name. Region availability changes; validate before apply."
  type        = string
  default     = "gpt-4o-mini"
}

variable "openai_chat_model_version" {
  type    = string
  default = "2024-07-18"
}

variable "openai_embedding_model_name" {
  type    = string
  default = "text-embedding-3-small"
}

variable "openai_embedding_model_version" {
  type    = string
  default = "1"
}
